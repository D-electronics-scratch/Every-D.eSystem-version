# D.eSystem-6.0.5-alpha

D.eSystem 6.0.5 alpha introduces major stability improvements across the entire kernel and ships with the brand‑new D.eShell, the first fully interactive command‑line interface of the D.eSystem platform.

This release also includes extended keyboard support and new key handling logic, powered by an upgraded low‑level driver.

Download the D.eSystem 6.0.5 alpha iso here: https://github.com/D-electronics-scratch/D.eSystem-6.0.5-alpha-iso-download
