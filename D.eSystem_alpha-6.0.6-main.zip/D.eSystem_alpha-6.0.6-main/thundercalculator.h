#pragma once

void thundercalc();